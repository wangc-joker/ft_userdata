from DualTrendCompressionRestartShortV1Strategy import DualTrendCompressionRestartShortV1Strategy

class DualTrendRobustRisk0p005Cap0p25Strategy(DualTrendCompressionRestartShortV1Strategy):
    risk_per_trade = 0.005
    max_position_value_pct = 0.25

class DualTrendRobustRisk0p005Cap0p35Strategy(DualTrendCompressionRestartShortV1Strategy):
    risk_per_trade = 0.005
    max_position_value_pct = 0.35

class DualTrendRobustRisk0p005Cap0p45Strategy(DualTrendCompressionRestartShortV1Strategy):
    risk_per_trade = 0.005
    max_position_value_pct = 0.45

class DualTrendRobustRisk0p0075Cap0p25Strategy(DualTrendCompressionRestartShortV1Strategy):
    risk_per_trade = 0.0075
    max_position_value_pct = 0.25

class DualTrendRobustRisk0p0075Cap0p35Strategy(DualTrendCompressionRestartShortV1Strategy):
    risk_per_trade = 0.0075
    max_position_value_pct = 0.35

class DualTrendRobustRisk0p0075Cap0p45Strategy(DualTrendCompressionRestartShortV1Strategy):
    risk_per_trade = 0.0075
    max_position_value_pct = 0.45

class DualTrendRobustRisk0p01Cap0p25Strategy(DualTrendCompressionRestartShortV1Strategy):
    risk_per_trade = 0.01
    max_position_value_pct = 0.25

class DualTrendRobustRisk0p01Cap0p35Strategy(DualTrendCompressionRestartShortV1Strategy):
    risk_per_trade = 0.01
    max_position_value_pct = 0.35

class DualTrendRobustRisk0p01Cap0p45Strategy(DualTrendCompressionRestartShortV1Strategy):
    risk_per_trade = 0.01
    max_position_value_pct = 0.45
